'use strict';

angular.module('netJamApp.admin', ['netJamApp.auth', 'ui.router']);
//# sourceMappingURL=admin.module.js.map
