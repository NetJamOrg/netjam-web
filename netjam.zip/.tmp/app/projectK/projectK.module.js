'use strict';

angular.module('netJamApp.profile', ['netJamApp.auth', 'ui.router']);
//# sourceMappingURL=projectK.module.js.map
