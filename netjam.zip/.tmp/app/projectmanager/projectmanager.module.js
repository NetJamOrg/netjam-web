'use strict';

angular.module('netJamApp.projectmanager', ['netJamApp.auth', 'ui.router']);
//# sourceMappingURL=projectmanager.module.js.map
