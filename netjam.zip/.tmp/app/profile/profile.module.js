'use strict';

angular.module('netJamApp.profile', ['netJamApp.auth', 'ui.router']);
//# sourceMappingURL=profile.module.js.map
