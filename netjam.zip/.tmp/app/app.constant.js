'use strict';

(function (angular, undefined) {
  'use strict';

  angular.module('netJamApp.constants', []).constant('appConfig', { userRoles: ['guest', 'user', 'admin'] });
})(angular);
//# sourceMappingURL=app.constant.js.map
