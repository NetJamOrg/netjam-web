'use strict';

angular.module('netJamApp.util', []);
//# sourceMappingURL=util.module.js.map
