'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var NavbarController = function () {
  //end-non-standard

  //start-non-standard

  function NavbarController(Auth, $uibModal, $http) {
    _classCallCheck(this, NavbarController);

    this.menu = [{
      'title': 'Home',
      'state': 'main',
      'show': 'true'
    }];
    this.isCollapsed = true;

    this.isLoggedIn = Auth.isLoggedIn;
    this.isAdmin = Auth.isAdmin;
    this.getCurrentUser = Auth.getCurrentUser;
    this.uibModal = $uibModal;
    this.searchString = '';
    this.http = $http;
  }

  // updateSearchTerm() {
  //   this.searchTerm = this.
  // }

  _createClass(NavbarController, [{
    key: 'openSearch',
    value: function openSearch() {
      var _this = this;

      if (this.searchString === "") {
        alert("Please enter something to search for!");
      } else {
        this.http.get("/api/users/search", { params: { searchterm: this.searchString } }).then(function (res) {
          return res.data;
        }).then(function (_users) {
          _this.http.get("/api/songs/search", { params: { searchterm: _this.searchString } }).then(function (res) {
            return res.data;
          }).then(function (_songs) {

            if (_users) _users.forEach(function (element, index, array) {
              element.type = 'User';element.url = "/profile/" + element._id;
            });
            if (_songs) _songs.forEach(function (element, index, array) {
              element.type = 'Song';element.url = "/songStorage/" + element._id;
            });

            var modalInstance = _this.uibModal.open({
              animation: true,
              templateUrl: 'mySearchModalContent.html',
              controller: 'SearchModalInstanceCtrl',
              // size: 'lg',
              resolve: {
                users: function users() {
                  return _users;
                },
                songs: function songs() {
                  return _songs;
                }
              }
            });
          });
        });
      }
    }
  }]);

  return NavbarController;
}();

angular.module('netJamApp').controller('NavbarController', NavbarController);

angular.module('netJamApp').controller('SearchModalInstanceCtrl', ['$scope', '$uibModalInstance', '$http', 'users', 'songs', function ($scope, $uibModalInstance, $http, users, songs) {

  var searchdata = [].concat(songs).concat(users).sort(function (a, b) {
    return new Date(b.createdAt) - new Date(a.createdAt);
  });
  $scope.searchitems = searchdata;

  $scope.close = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.isResults = function () {
    return $scope.searchitems.length;
  };
}]);
//# sourceMappingURL=navbar.controller.js.map
