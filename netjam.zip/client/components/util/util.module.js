'use strict';

angular.module('netJamApp.util', []);
