'use strict';

angular.module('netJamApp.admin', [
  'netJamApp.auth',
  'ui.router'
]);
