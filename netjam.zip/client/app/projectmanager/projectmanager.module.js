'use strict';

angular.module('netJamApp.projectmanager', [
  'netJamApp.auth',
  'ui.router'
]);
