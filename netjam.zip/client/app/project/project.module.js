'use strict';

angular.module('netJamApp.project', [
  'ui.router', 'ngMaterial'
]);
