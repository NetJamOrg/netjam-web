'use strict';

app.directive('recordingDirective', function () {
	return{
		/*
		restrict: "A",
		link: function(scope, element){
			console.log("diective");
			console.log(element[0]);
			console.log(element[1]);
		}
		*/
	};
});