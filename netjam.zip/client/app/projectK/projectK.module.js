'use strict';

angular.module('netJamApp.profile', [
  'netJamApp.auth',
  'ui.router'
]);
